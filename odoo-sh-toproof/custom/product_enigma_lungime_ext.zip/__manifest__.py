{
    "name": "Product Enigma Lungime Variabila - Extins",
    "version": "1.1",
    "author": "Toproof / Emil Sterea",
    "category": "Sales",
    "summary": "Produs cu lungime variabila, calcul suprafata si pret automat in ofertare.",
    "depends": ["sale", "product"],
    "data": [],
    "installable": True,
    "auto_install": False
}
