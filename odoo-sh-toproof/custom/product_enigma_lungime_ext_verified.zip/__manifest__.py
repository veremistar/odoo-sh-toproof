{
    "name": "Product Enigma Lungime Variabila - Verified",
    "version": "1.2",
    "author": "Toproof / Emil Sterea",
    "license": "LGPL-3",
    "category": "Sales",
    "summary": "Produs cu lungime variabila, suprafata si pret calculat automat în ofertare.",
    "depends": ["sale", "product"],
    "data": [],
    "installable": True,
    "auto_install": False
}
