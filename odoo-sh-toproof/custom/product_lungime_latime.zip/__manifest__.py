{
    "name": "Product Lungime si Latime",
    "version": "1.0",
    "depends": ["product"],
    "author": "Toproof / Emil Sterea",
    "category": "Product",
    "description": "Calculeaza pretul in functie de lungime variabila si latime fixa 1.176m.",
    "installable": True,
    "application": False,
    "auto_install": False
}
