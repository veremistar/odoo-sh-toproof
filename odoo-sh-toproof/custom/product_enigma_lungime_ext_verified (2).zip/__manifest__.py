{
    "name": "Product Enigma Lungime Variabila - Extins",
    "version": "1.2",
    "author": "Toproof / Emil Sterea",
    "license": "LGPL-3",
    "category": "Sales",
    "summary": "Produs cu lungime variabilă, suprafață și preț calculat automat în ofertare.",
    "depends": ["sale", "product"],
    "data": [
        "views/product_template_view.xml"
    ],
    "installable": True,
    "auto_install": False
}