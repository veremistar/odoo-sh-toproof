{
    "name": "Product Enigma Lungime Variabila",
    "version": "1.0",
    "author": "Toproof / Emil Sterea",
    "category": "Sales",
    "summary": "Produs cu lungime variabila in ofertare, latime fixa 1.176m si pret/m2 configurabil.",
    "depends": ["sale", "product"],
    "data": [],
    "installable": True,
    "auto_install": False
}
