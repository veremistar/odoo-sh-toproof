{
    "name": "Product Enigma Lungime Variabila - Extins",
    "version": "1.2",
    "author": "Toproof / Emil Sterea",
    "license": "LGPL-3",
    "category": "Sales",
    "summary": "Produs Enigma cu lungime variabila, calcul automat al pretului in functie de suprafata.",
    "depends": ["sale", "product"],
    "data": ["views/product_template_view.xml"],
    "installable": True,
    "auto_install": False
}
